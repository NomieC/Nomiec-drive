#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <errno.h>
#include <string.h>

int main(int argc, char *argv[]) {
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <directory>\n", argv[0]);
        return EXIT_FAILURE;
    }

    for (int i = 1; i < argc; i++) {
        DIR *dir = opendir(argv[i]);

        if (dir == NULL) {
            if (errno == ENOENT) {
                fprintf(stderr, "Error: Directory '%s' does not exist.\n", argv[i]);
            } else {
                perror("Error");
            }
            continue;
        }

        struct dirent *entry;
        printf("\nContents of directory '%s':\n", argv[i]);
        while ((entry = readdir(dir)) != NULL) {
            printf("%s\n", entry->d_name);
        }

        closedir(dir);
    }

    return EXIT_SUCCESS;
}
