#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

typedef struct {
    int id;
    char *document;
} Job;

sem_t printer_sem;

int printer_available = 1;

void *print_document(void *arg) {
    Job *job = (Job *) arg;
    //Printer dipake
    sem_wait(&printer_sem);
    printf("Proses %d memulai pencetakan %s\n", job->id, job->document);
    sleep(1);
    printf("Proses %d sedang mencetak %s\n", job->id, job->document);
    sleep(1);
    printf("Proses %d selesai mencetak %s\n", job->id, job->document);
    sleep(1);
    //Printer dapat digunakan
    printer_available = 1;
    sem_post(&printer_sem);

    return NULL;
}

int main(int argc, char *argv[]) {
    // semaphore
    sem_init(&printer_sem, 0, printer_available);
    //buat jobsnya
    Job jobs[5] = { {1, "Dokumen abby"}, {2, "Dokumen freya"}, {3, "Dokumen michie"}, {4, "Dokumen fidel"}, {5, "Dokumen windah"},
    };
    //buat threads
    pthread_t threads[5];
    for (int i = 0; i < 5; i++) {
        if (pthread_create(&threads[i], NULL, print_document, &jobs[i]) != 0) {
            perror("Error creating thread");
            exit(1);
        }
    }
    for (int i = 0; i < 5; i++) {
        pthread_join(threads[i], NULL);
    }
    sem_destroy(&printer_sem);

    return 0;
}
