# Social media icon #5

A Pen created on CodePen.io. Original URL: [https://codepen.io/OfigenusMaximus/pen/yLKOpqb](https://codepen.io/OfigenusMaximus/pen/yLKOpqb).

