# Parallax Grid

A Pen created on CodePen.io. Original URL: [https://codepen.io/caseycallis/pen/pwEWxo](https://codepen.io/caseycallis/pen/pwEWxo).

I used parallax.js to set up this interactive panning image grid. Uses cursor position if you're on a desktop or laptop. 