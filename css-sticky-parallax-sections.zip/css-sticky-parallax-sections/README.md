# CSS Sticky Parallax Sections

A Pen created on CodePen.io. Original URL: [https://codepen.io/hexagoncircle/pen/JjRYaZw](https://codepen.io/hexagoncircle/pen/JjRYaZw).

Uses position: sticky and scale transforms to create a sticky parallax effect with CSS.